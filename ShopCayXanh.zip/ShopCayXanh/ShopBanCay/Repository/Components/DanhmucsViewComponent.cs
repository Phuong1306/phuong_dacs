﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ShopBanCay.Repository.Components
{
	public class DanhmucsViewComponent : ViewComponent
	{
		private readonly TreeDbContext _treeDbContext;
		
			public DanhmucsViewComponent(TreeDbContext context)
		{
			_treeDbContext = context;
		}
		public async Task<IViewComponentResult> InvokeAsync() => View(await _treeDbContext.DanhMucs.ToListAsync());
	}
}
