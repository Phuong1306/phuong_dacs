﻿using Microsoft.EntityFrameworkCore;
using ShopBanCay.Models;

namespace ShopBanCay.Repository
{
	public class SeedData
	{
		public static void SeedingData(TreeDbContext _context)
		{
			_context.Database.Migrate();
			if (!_context.SanPhams.Any())
			{
				DanhMucModel HybridPlant = new DanhMucModel { Name = "Cây lai", Slug = "Cây lai", Description = "Cây lai từ 2 giống khác nhau", Status=1 };
				DanhMucModel Bonsai = new DanhMucModel { Name = "Cây kiểng", Slug = "Cây kiểng", Description = "Cây trồng trong chậu người Nhật gọi là “Bonsai” còn ở Việt Nam ta thường gọi là “Bồn cảnh”, “Chậu cảnh.", Status=1 };
                DanhMucModel CayTrongNha = new DanhMucModel { Name = "Cây trong nhà", Slug = "Cây trong nhà", Description = "Cây trồng trong nhà", Status = 1 };
                DanhMucModel CayNgoaiVuon = new DanhMucModel { Name = "Cây ngoài vườn", Slug = "Cây ngoài vườn", Description = "Cây trồng ngoài nhà", Status = 1 };
                _context.SanPhams.AddRange(

				new SanPhamModel { Name = "Cây Chuối", Slug = "Cây Chuối", Description = "Cây chuối là một loại cây thường mọc thành bụi và được trồng rất nhiều trong vườn.", Image = "caychuoi.jpg", DanhMuc = CayNgoaiVuon, Price = 100 },
                new SanPhamModel { Name = "Cây cà phê", Slug = "Cây cà phê", Description = "Cà phê là tên một chi thực vật thuộc họ Thiến thảo (Rubiaceae). Họ này bao gồm khoảng 500 chi khác nhau với trên 6.000 loài cây nhiệt đới.", Image = "caycafe.jpg", DanhMuc = CayTrongNha, Price = 200 }


                    );
				_context.SaveChanges();
			}
		}
	}
}
