﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ShopBanCay.Models;

namespace ShopBanCay.Repository
{
	public class TreeDbContext : IdentityDbContext<AppUserModel>
	{
		public TreeDbContext(DbContextOptions<TreeDbContext> options) : base(options) 
		{
		
		}
		public DbSet<SanPhamModel> SanPhams { get; set; }
		public DbSet<DanhMucModel> DanhMucs { get; set; }
	}
}
