﻿using Microsoft.AspNetCore.Mvc;
using ShopBanCay.Models;
using ShopBanCay.Models.ViewModels;
using ShopBanCay.Repository;

namespace ShopBanCay.Controllers
{
    public class GioHangController : Controller
    {
        private readonly TreeDbContext _treeDbContext;
        public GioHangController(TreeDbContext _context)
        {
            _treeDbContext = _context;
        }

        public IActionResult Index()
        {
            List<GioHangItemModel> gioHangItems = HttpContext.Session.GetJson<List<GioHangItemModel>>("GioHang") ?? new List<GioHangItemModel>();
            GioHangItemViewModel giohangVM = new()
            {
                GioHangItems = gioHangItems,
                GrandTongTien = gioHangItems.Sum(x => x.SoLuong * x.Price)
            };
            return View(giohangVM);
        }
        public IActionResult ThanhToan()
        {
            return View("~/Views/ThanhToan/Index.cshtml");
        }
        public async Task<IActionResult> Add(int Id)
        {
            SanPhamModel sanPham = await _treeDbContext.SanPhams.FindAsync(Id);
            List<GioHangItemModel> gioHang = HttpContext.Session.GetJson<List<GioHangItemModel>>("GioHang") ?? new List<GioHangItemModel>();
            GioHangItemModel gioHangItems = gioHang.Where(c => c.SanPhamId == Id).FirstOrDefault();

            if (gioHangItems == null)
            {
                gioHang.Add(new GioHangItemModel(sanPham));
            }
            else
            {
                gioHangItems.SoLuong += 1;
            }

            //lưu trữ dữ liêu giỏ hàng và session giỏ hàng
            HttpContext.Session.SetJson("GioHang", gioHang);

            TempData["success"] = "Thêm mặt hàng vào giỏ hàng thành công";

            return Redirect(Request.Headers["Referer"].ToString());
        }
        public async Task<IActionResult> Decrease(int Id)
        {
            //lấy ra sản phẩm bằng Id cần giảm số lượng
            List<GioHangItemModel> gioHang = HttpContext.Session.GetJson<List<GioHangItemModel>>("GioHang");

            GioHangItemModel gioHangItem = gioHang.Where(c => c.SanPhamId == Id).FirstOrDefault();

            if (gioHangItem.SoLuong > 1)
            {
                --gioHangItem.SoLuong;
            }
            else
            {
                gioHang.RemoveAll(p => p.SanPhamId == Id);
            }
            if (gioHang.Count == 0)
            {
                HttpContext.Session.Remove("GioHang");
            }
            else
            {
                HttpContext.Session.SetJson("GioHang", gioHang);

            }

            TempData["success"] = "Giảm số lượng mặt hàng trong giỏ hàng thành công";
            return RedirectToAction("Index");
        }


        public async Task<IActionResult> Increase(int Id)
        {
            //lấy ra sản phẩm bằng Id cần tăng số lượng
            List<GioHangItemModel> gioHang = HttpContext.Session.GetJson<List<GioHangItemModel>>("GioHang");

            GioHangItemModel gioHangItem = gioHang.Where(c => c.SanPhamId == Id).FirstOrDefault();

            if (gioHangItem.SoLuong >= 1)
            {
                ++gioHangItem.SoLuong;
            }
            else
            {
                gioHang.RemoveAll(p => p.SanPhamId == Id);
            }
            if (gioHang.Count == 0)
            {
                HttpContext.Session.Remove("GioHang");
            }
            else
            {
                HttpContext.Session.SetJson("GioHang", gioHang);

            }
            TempData["success"] = "Tăng số lượng mặt hàng trong giỏ hàng thành công";
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Remove(int Id)
		{
			List<GioHangItemModel> gioHang = HttpContext.Session.GetJson<List<GioHangItemModel>>("GioHang");
			GioHangItemModel gioHangItem = gioHang.Where(c => c.SanPhamId == Id).FirstOrDefault();

			gioHang.RemoveAll(p => p.SanPhamId == Id);

			if (gioHang.Count == 0)
			{
				HttpContext.Session.Remove("GioHang");
			}
			else
			{
				HttpContext.Session.SetJson("GioHang", gioHang);

			}
            TempData["success"] = "Xóa mặt hàng trong giỏ hàng thành công";
            return RedirectToAction("Index");
		}
		public async Task<IActionResult> Clear()
        {
			HttpContext.Session.Remove("GioHang");

            TempData["success"] = "Dọn tất cả mặt hàng trong giỏ hàng thành công";
            return RedirectToAction("Index");
		}

	}
}
