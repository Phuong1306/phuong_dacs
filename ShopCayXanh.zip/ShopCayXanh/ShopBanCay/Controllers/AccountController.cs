﻿using Microsoft.AspNetCore.Mvc;

namespace ShopBanCay.Controllers
{
	public class AccountController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}
	}
}
