﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopBanCay.Models;
using ShopBanCay.Repository;
using System.Diagnostics;

namespace ShopBanCay.Controllers
{
    public class HomeController : Controller
    {
        private readonly TreeDbContext _treeDbContext;

        private readonly ILogger<HomeController> _logger;


        public HomeController(ILogger<HomeController> logger, TreeDbContext context)
        {
            _logger = logger;
            _treeDbContext = context;
        }

        public IActionResult Index()
        {
            var sanphams = _treeDbContext.SanPhams.Include("DanhMuc").ToList();
            return View(sanphams);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error(int statuscode)
        {
            if(statuscode == 404)
            {
                return View("NotFound");
            }
            else 
            {
                return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }

        }
    }
}
