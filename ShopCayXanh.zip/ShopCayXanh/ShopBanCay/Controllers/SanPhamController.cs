﻿using Microsoft.AspNetCore.Mvc;
using ShopBanCay.Repository;

namespace ShopBanCay.Controllers
{
	public class SanPhamController : Controller
	{
		private readonly TreeDbContext _treeDbContext;
		public SanPhamController(TreeDbContext context)
		{
			_treeDbContext = context;
		}

		public IActionResult Index()
		{
			return View();
		}
		public async Task<IActionResult> ChiTietSanPham(int Id)
		{
			if (Id == null) return RedirectToAction("Index");
			var sanphamsById = _treeDbContext.SanPhams.Where(p => p.Id == Id).FirstOrDefault();
			return View(sanphamsById);
		}
	}
}