﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopBanCay.Models;
using ShopBanCay.Repository;

namespace ShopBanCay.Controllers
{
	public class DanhMucController : Controller
	{
		private readonly TreeDbContext _treeDbContext;
		public DanhMucController(TreeDbContext context)
		{
			_treeDbContext = context;
		}

		public async Task<IActionResult> Index(String Slug = "")
		{
			DanhMucModel danhMuc = _treeDbContext.DanhMucs.Where(c => c.Slug == Slug).FirstOrDefault();
			if (danhMuc == null) return RedirectToAction("Index");
			var sanphamsByDanhMuc = _treeDbContext.SanPhams.Where(p => p.DanhMucId == danhMuc.Id);
			return View(await sanphamsByDanhMuc.OrderByDescending(p => p.Id).ToListAsync());
		}
	}
}
