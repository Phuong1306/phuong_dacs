﻿using Microsoft.AspNetCore.Identity;
namespace ShopBanCay.Models
{
	public class AppUserModel : IdentityUser
	{
		public string Occupation { get; set; }
	}
}
