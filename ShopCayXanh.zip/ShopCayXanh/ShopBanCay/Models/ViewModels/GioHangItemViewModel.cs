﻿namespace ShopBanCay.Models.ViewModels
{
	public class GioHangItemViewModel
	{
		public List<GioHangItemModel> GioHangItems { get; set; }
		public decimal GrandTongTien {  get; set; }
	}
}
