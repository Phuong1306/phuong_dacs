﻿namespace ShopBanCay.Models
{
	public class GioHangItemModel
	{
		public long SanPhamId { get; set; }

		public string SanPhamName { get; set;}

		public int SoLuong { get; set; }

		public decimal Price { get; set; }

		public decimal TongTien
		{
			get { return SoLuong*Price; }
		}

		public string Image { get; set; }
		public GioHangItemModel()
		{

		}

		public GioHangItemModel(SanPhamModel sanPham) 
		{
			SanPhamId = sanPham.Id;
			SanPhamName = sanPham.Name;
			Price = sanPham.Price;
			SoLuong = 1;
			Image = sanPham.Image;
		}
	}
}
