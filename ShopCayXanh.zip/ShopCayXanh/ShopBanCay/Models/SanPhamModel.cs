﻿using ShopBanCay.Repository.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShopBanCay.Models
{
	public class SanPhamModel
	{
		[Key]
		public int Id { get; set; }


		[Required, MinLength(4, ErrorMessage = "Yêu cầu nhập tên Sản phẩm")]
		public string Name { get; set; }

		public string Slug { get; set; }


		[Required, MinLength(4, ErrorMessage = "Yêu cầu nhập mô tả Sản phẩm")]
		public string Description { get; set; }


		[Required( ErrorMessage = "Yêu cầu nhập giá Sản phẩm")]
		[Range(0.01, double.MaxValue)]
		[Column(TypeName ="decimal(15, 2)")]

		public Decimal Price { get; set;}

		[Required, Range(1,int.MaxValue,ErrorMessage = "Chọn một danh mục")]
		public int DanhMucId { get; set; }

		public DanhMucModel DanhMuc { get; set; }

		public string Image { get; set; } = "noimage.jpg";

		[NotMapped]
		[FileExtension]
		public IFormFile ImageUpload { get; set; }
	}
}
