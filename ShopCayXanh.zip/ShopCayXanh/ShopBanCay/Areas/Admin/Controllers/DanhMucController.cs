﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ShopBanCay.Models;
using ShopBanCay.Repository;

namespace ShopBanCay.Areas.Admin.Controllers
{

	[Area("Admin")]
	public class DanhMucController : Controller
	{
		private readonly TreeDbContext _treeDbContext;
		public DanhMucController(TreeDbContext context)
		{
			_treeDbContext = context;
		}
		public async Task<IActionResult> Index()
		{
			return View(await _treeDbContext.DanhMucs.OrderByDescending(p => p.Id).ToListAsync());
		}
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DanhMucModel danhMuc)
        {
        
            if (ModelState.IsValid) //nếu tình trạng model product được cho phép
            {
                danhMuc.Slug = danhMuc.Name.Replace(" ", "-");
                var slug = await _treeDbContext.DanhMucs.FirstOrDefaultAsync(p => p.Slug == danhMuc.Slug); //tìm sp dựa vào slug
                if (slug != null)
                {
                    ModelState.AddModelError("", "Danh mục đã có");
                    return View(danhMuc);
                }

                _treeDbContext.Add(danhMuc);
                await _treeDbContext.SaveChangesAsync();
                TempData["success"] = "Thêm danh mục thành công";
                return RedirectToAction("Index");

            }
            else
            {
                TempData["error"] = "Model có một vài thứ đang bị lỗi";
                List<string> errors = new List<string>();
                foreach (var value in ModelState.Values)
                {
                    foreach (var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errorMessage = string.Join("\n", errors);
                return BadRequest(errorMessage);
            }

            return View(danhMuc);
        }
        public async Task<IActionResult> Delete(int Id)
        {
            DanhMucModel danhMuc = await _treeDbContext.DanhMucs.FindAsync(Id);
 
            _treeDbContext.Remove(danhMuc);
           // await _treeDbContext.SaveChangesAsync(); không đụng vào
            TempData["success"] = "Danh mục đã xóa thành công";
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Edit(int Id)
        {
            DanhMucModel danhMuc = await _treeDbContext.DanhMucs.FindAsync(Id);
            return View(danhMuc);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(DanhMucModel danhMuc)
        {

            if (ModelState.IsValid) //nếu tình trạng model product được cho phép
            {
                danhMuc.Slug = danhMuc.Name.Replace(" ", "-");
                var slug = await _treeDbContext.DanhMucs.FirstOrDefaultAsync(p => p.Slug == danhMuc.Slug); //tìm sp dựa vào slug
                if (slug != null)
                {
                    ModelState.AddModelError("", "Danh mục đã có");
                    return View(danhMuc);
                }

                _treeDbContext.Update(danhMuc);
                await _treeDbContext.SaveChangesAsync();
                TempData["success"] = "Cập nhật danh mục thành công";
                return RedirectToAction("Index");

            }
            else
            {
                TempData["error"] = "Model có một vài thứ đang bị lỗi";
                List<string> errors = new List<string>();
                foreach (var value in ModelState.Values)
                {
                    foreach (var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errorMessage = string.Join("\n", errors);
                return BadRequest(errorMessage);
            }

            return View(danhMuc);
        }

    }
}
