﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ShopBanCay.Models;
using ShopBanCay.Repository;


namespace ShopBanCay.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class SanPhamController : Controller
    {
        private readonly TreeDbContext _treeDbContext;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public SanPhamController(TreeDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _treeDbContext = context;
            _webHostEnvironment = webHostEnvironment;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _treeDbContext.SanPhams.OrderByDescending(p => p.Id).Include(p => p.DanhMuc).ToListAsync());
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.DanhMucs = new SelectList(_treeDbContext.DanhMucs, "Id", "Name"); //lấy ra ds danh mục
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SanPhamModel sanPham)
        {
            ViewBag.DanhMucs = new SelectList(_treeDbContext.DanhMucs, "Id", "Name", sanPham.DanhMucId); //lấy name và id gửi qua từ form
            if (ModelState.IsValid) //nếu tình trạng model product được cho phép
            {
                sanPham.Slug = sanPham.Name.Replace(" ", "-");
                var slug = await _treeDbContext.SanPhams.FirstOrDefaultAsync(p => p.Slug == sanPham.Slug); //tìm sp dựa vào slug
                if (slug != null)
                {
                    ModelState.AddModelError("", "Sản phẩm đã có");
                    return View(sanPham);
                }
                if (sanPham.ImageUpload != null)
                {
                    string uploadsDir = Path.Combine(_webHostEnvironment.WebRootPath, "media/products");
                    string imageName = Guid.NewGuid().ToString() + "_" + sanPham.ImageUpload.FileName;
                    string filePath = Path.Combine(uploadsDir, imageName);

                    FileStream fs = new FileStream(filePath, FileMode.Create);
                    await sanPham.ImageUpload.CopyToAsync(fs);
                    fs.Close();
                    sanPham.Image = imageName;
                }

                _treeDbContext.Add(sanPham);
                await _treeDbContext.SaveChangesAsync();
                TempData["success"] = "Thêm sản phẩm thành công";
                return RedirectToAction("Index");

            }
            else
            {
                TempData["error"] = "Model có một vài thứ đang bị lỗi";
                List<string> errors = new List<string>();
                foreach (var value in ModelState.Values)
                {
                    foreach (var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errorMessage = string.Join("\n", errors);
                return BadRequest(errorMessage);
            }

            return View(sanPham);
        }

        public async Task<IActionResult> Edit(int Id)
        {
            
              SanPhamModel sanPham = await _treeDbContext.SanPhams.FindAsync(Id);
              ViewBag.DanhMucs = new SelectList(_treeDbContext.DanhMucs, "Id", "Name", sanPham.DanhMucId); //lấy name và id gửi qua từ form
              return View(sanPham);
            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int Id, SanPhamModel sanPham)
        {
            ViewBag.DanhMucs = new SelectList(_treeDbContext.DanhMucs, "Id", "Name", sanPham.DanhMucId); //lấy name và id gửi qua từ form
            if (ModelState.IsValid) //nếu tình trạng model product được cho phép
            {
                sanPham.Slug = sanPham.Name.Replace(" ", "-");
                var slug = await _treeDbContext.SanPhams.FirstOrDefaultAsync(p => p.Slug == sanPham.Slug); //tìm sp dựa vào slug
                if (slug != null)
                {
                    ModelState.AddModelError("", "Sản phẩm đã có");
                    return View(sanPham);
                }
                if (sanPham.ImageUpload != null)
                {
                    string uploadsDir = Path.Combine(_webHostEnvironment.WebRootPath, "media/products");
                    string imageName = Guid.NewGuid().ToString() + "_" + sanPham.ImageUpload.FileName;
                    string filePath = Path.Combine(uploadsDir, imageName);

                    FileStream fs = new FileStream(filePath, FileMode.Create);
                    await sanPham.ImageUpload.CopyToAsync(fs);
                    fs.Close();
                    sanPham.Image = imageName;
                }

                _treeDbContext.Update(sanPham);
                await _treeDbContext.SaveChangesAsync();
                TempData["success"] = "cập nhật thành công";
                return RedirectToAction("Index");

            }
            else
            {
                TempData["error"] = "Model có một vài thứ đang bị lỗi";
                List<string> errors = new List<string>();
                foreach (var value in ModelState.Values)
                {
                    foreach (var error in value.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                string errorMessage = string.Join("\n", errors);
                return BadRequest(errorMessage);
            }

            return View(sanPham);
        }
        public async Task<IActionResult> Delete(int Id)
        {
            SanPhamModel sanPham = await _treeDbContext.SanPhams.FindAsync(Id);
            if (!string.Equals(sanPham.Image, "noname.jpg"))
            {
                string uploadsDir = Path.Combine(_webHostEnvironment.WebRootPath, "media/products");
                string oldfileImage = Path.Combine(uploadsDir, sanPham.Image);
               if (System.IO.File.Exists(oldfileImage))
                {
                    System.IO.File.Delete(oldfileImage);
                }
            }

            _treeDbContext.Remove(sanPham);
            await _treeDbContext.SaveChangesAsync();
            TempData["success"] = "Sản phẩm đã xóa thành công";
            return RedirectToAction("Index");
        }
    }
}
